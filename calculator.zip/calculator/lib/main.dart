import 'package:flutter/material.dart';
import 'calculator_app.dart';


void main() {
  runApp(MyApp());
}